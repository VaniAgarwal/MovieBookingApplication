package com.upgrad.user.controller;


import com.upgrad.user.dto.UserDTO;
import com.upgrad.user.entities.User;
import com.upgrad.user.service.UserService;
import com.upgrad.user.utils.POJOConvertor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "user_app/v1")
public class UserController {

    @Autowired
    private UserService userService;

    /**
     * Create a post API
     *
     * 127.0.0.1:8082/user_app/v1/users  POST
     */

    @PostMapping(value = "/users",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createUser(@RequestBody UserDTO userDTO){

        //convert userDTO to Entity
        User user = POJOConvertor.convertUserDTOToEntity(userDTO);

        User savedUser = userService.createUser(user);

        UserDTO savedUserDTO = POJOConvertor.convertUserEntityToDTO(user);

        return new ResponseEntity<>(savedUserDTO, HttpStatus.CREATED);

    }

    /**
     * Get the list of all the users
     *
     * 127.0.0.1:8082/users_app/v1/users  GET
     */

    @GetMapping(value = "/allUsers",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getAllUsers(){

        List<User> usersList = userService.getAllUsers();

        List<UserDTO> userDTOList = new ArrayList<>();

        usersList.forEach(u -> userDTOList.add(POJOConvertor.convertUserEntityToDTO(u)));

        return new ResponseEntity(userDTOList,HttpStatus.OK);

    }

    /**
     * Get the user based on Id
     *
     * 127.0.0.1:8080/users_app/v1/user/{id} GET
     */

    @GetMapping(value = "/user/{id}")
    public ResponseEntity getUser(@PathVariable(name = "id") int id){

        User user = userService.getUserBasedOnId(id);

        UserDTO userDTO = POJOConvertor.convertUserEntityToDTO(user);

        return new ResponseEntity<>(userDTO,HttpStatus.OK);
    }

    /**
     *
     * Update the user
     *
     * 127.0.0.1:8080/users_app/v1/user/{id}  PUT
     *
     * Request Body will be present {}
     */

    @PutMapping(value = "/user",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updateUser(@RequestBody UserDTO userDTO){

        User userToBeUpdated = POJOConvertor.convertUserDTOToEntity(userDTO);
        User savedUpdatedUser = userService.updateUser(userToBeUpdated);

        UserDTO updateduserDto = POJOConvertor.convertUserEntityToDTO(savedUpdatedUser);

        return new ResponseEntity(updateduserDto,HttpStatus.ACCEPTED);

    }

    /**
     *
     * 127.0.0.1:8080/users_app/v1/users/{id} --delete
     */

    @DeleteMapping(value = "users/{id}")
    public ResponseEntity deleteUser(@PathVariable int id){

        User user = userService.getUserBasedOnId(id);

        userService.deleteUser(user);

        return new ResponseEntity(null,HttpStatus.OK);

    }


}