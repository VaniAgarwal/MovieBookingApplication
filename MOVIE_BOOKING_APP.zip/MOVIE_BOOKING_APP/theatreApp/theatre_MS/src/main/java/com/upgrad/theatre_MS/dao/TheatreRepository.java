package com.upgrad.theatre_MS.dao;

import com.upgrad.theatre_MS.entities.Theatre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TheatreRepository  extends JpaRepository<Theatre,Integer> , PagingAndSortingRepository<Theatre,Integer> {

    public Theatre findByTheatreIdAndMovieId(int theatreId,int movieId);
    Theatre findByTheatreName(String name);
    List<Theatre> findByTicketPriceLessThan(float cost);
    List<Theatre>findByTheatreNameContaining(String nameContaining);
}
