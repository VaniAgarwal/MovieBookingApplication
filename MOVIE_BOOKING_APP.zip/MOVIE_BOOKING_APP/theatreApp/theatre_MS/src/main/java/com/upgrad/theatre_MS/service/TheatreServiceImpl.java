package com.upgrad.theatre_MS.service;

import com.upgrad.theatre_MS.dao.TheatreRepository;
import com.upgrad.theatre_MS.entities.Theatre;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TheatreServiceImpl implements TheatreService {

    @Autowired
    TheatreRepository theatreRepository;

    @Override
    public Theatre getTheatreDetails(int theatreId, int movieId) {

        Theatre requestedTheatre = theatreRepository.findByTheatreIdAndMovieId(theatreId,movieId);

        if(requestedTheatre!=null){
            return requestedTheatre;
        }
        return null;
    }

    @Override
    public Theatre acceptTheatreDetails(Theatre theatre) {
        return theatreRepository.save(theatre);
    }

    @Override
    public Theatre getTheatreDetailsById(int id) {
        return theatreRepository.findById(id).get();
    }

    @Override
    public Theatre updateTheatreDetails(int id, Theatre theatre) {
        Theatre savedTheatre = getTheatreDetailsById(id);
        savedTheatre.setTheatreName(theatre.getTheatreName());
        return theatreRepository.save(savedTheatre) ;
    }

    @Override
    public boolean deleteTheatre(int id) {
        Theatre theatre = getTheatreDetailsById(id);
        if(theatre == null){
            return false;
        }
        theatreRepository.delete(theatre);
        return true;
    }

    @Override
    public List<Theatre> getAllTheatreDetails() {

        List<Theatre> theatres = theatreRepository.findAll();
        return theatres;
    }
}
