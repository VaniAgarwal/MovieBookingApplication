package com.upgrad.theatre_MS.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Theatre {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int theatreId ;

    @Column( length=50, nullable = false , unique = true)
    private String theatreName ;

    @Column(name = "ticket_price",nullable = false)
    private float ticketPrice=150.00f;

    @Column(name="movie_id", length = 500, nullable = false)
    private int movieId ;
}
