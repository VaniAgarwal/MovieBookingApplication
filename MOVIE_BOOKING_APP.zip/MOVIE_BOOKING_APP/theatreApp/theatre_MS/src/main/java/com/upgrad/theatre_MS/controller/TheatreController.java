package com.upgrad.theatre_MS.controller;


import com.upgrad.theatre_MS.dto.CreateTheatreDTO;
import com.upgrad.theatre_MS.dto.TheatreDTO;
import com.upgrad.theatre_MS.entities.Theatre;
import com.upgrad.theatre_MS.service.TheatreService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.attribute.standard.Media;

@RestController
@RequestMapping(value = "/theatre_app/v1")
public class TheatreController {

    @Autowired
    TheatreService theatreService;

    @Autowired
    ModelMapper modelMapper;

    @PostMapping(value = "/theatre",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createTheatre(@RequestBody CreateTheatreDTO theatreDTO){


        //dto to entity
        Theatre newTheatre = modelMapper.map(theatreDTO,Theatre.class);

        Theatre savedTheatre = theatreService.acceptTheatreDetails(newTheatre);

        //entity to dto

        CreateTheatreDTO savedTheatreDTO = modelMapper.map(savedTheatre,CreateTheatreDTO.class);

        return new ResponseEntity<>(savedTheatreDTO,HttpStatus.CREATED);
    }

    @GetMapping(value = "/theatres/{theatreId}/movie/{movieId}",produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getTheatreFromId(@PathVariable(name = "theatreId") int theatreId,
                                           @PathVariable(name = "movieId") int movieId){

        Theatre responseTheatre = theatreService.getTheatreDetails(theatreId,movieId);

        if(responseTheatre!=null){
            TheatreDTO responseTheatreDTO = modelMapper.map(responseTheatre,TheatreDTO.class);
            return new ResponseEntity<>(responseTheatreDTO, HttpStatus.OK);
        }
        else {
            return null;
        }

    }

}
