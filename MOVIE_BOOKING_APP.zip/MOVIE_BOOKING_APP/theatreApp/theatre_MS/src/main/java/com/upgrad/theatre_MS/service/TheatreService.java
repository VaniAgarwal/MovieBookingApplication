package com.upgrad.theatre_MS.service;

import com.upgrad.theatre_MS.entities.Theatre;

import java.util.List;

public interface TheatreService {
    public Theatre getTheatreDetails(int theatreId, int movieId);
    public Theatre getTheatreDetailsById(int id);
    public Theatre acceptTheatreDetails(Theatre theatre);
    public Theatre updateTheatreDetails(int id, Theatre theatre) ;
    public boolean deleteTheatre(int id);
    public List<Theatre> getAllTheatreDetails();
}
