package com.upgrad.theatre_MS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TheatreMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
