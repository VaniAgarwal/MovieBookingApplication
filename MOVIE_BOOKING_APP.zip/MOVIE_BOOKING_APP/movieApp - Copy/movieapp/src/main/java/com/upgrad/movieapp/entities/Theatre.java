package com.upgrad.movieapp.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "Theatre")
public class Theatre {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int theatreId;

    @Column(name = "theatre_name",nullable = false,unique = true)
    private String theatreName;


    @Column(name = "ticket_price",nullable = false)
    private float ticketPrice=150.00f;

//    @ManyToOne
//    @JoinColumn(name = "city_id", nullable = false)
//    private City cityId;
//
//    @ManyToMany(mappedBy = "theatres")
//    private Set<Movie> movies;

    @Column(name = "movie_id")
    private int movieId;


}
