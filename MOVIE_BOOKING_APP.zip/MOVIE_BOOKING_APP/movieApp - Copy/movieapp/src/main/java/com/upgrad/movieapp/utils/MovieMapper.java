package com.upgrad.movieapp.utils;

import com.upgrad.movieapp.dto.MovieDTO;
import com.upgrad.movieapp.entities.Movie;
import org.modelmapper.ModelMapper;

public class MovieMapper extends ModelMapper {


    public MovieDTO movieEntityToDTO(Movie movieEntity){
        MovieDTO movieDTO = new MovieDTO();
        movieDTO.setMovie_id(movieEntity.getMovie_id());

        movieDTO.setMovieName(movieEntity.getMovieName());
        movieDTO.setMovieDesc(movieEntity.getMovieDesc());
        movieDTO.setReleaseDate(movieEntity.getReleaseDate());
        movieDTO.setDuration(movieEntity.getDuration());
        movieDTO.setCoverPhotoUrl(movieEntity.getCoverPhotoUrl());
        movieDTO.setTrailerUrl(movieEntity.getTrailerUrl());

        return movieDTO;
    }

    public Movie movieDTOTOEntity(MovieDTO movieDTO){
        Movie movie = new Movie();
        movie.setMovie_id(movieDTO.getMovie_id());
        movie.setMovieName(movieDTO.getMovieName());
        movie.setMovieDesc(movieDTO.getMovieDesc());
        movie.setReleaseDate(movieDTO.getReleaseDate());
        movie.setDuration(movieDTO.getDuration());
        movie.setCoverPhotoUrl(movieDTO.getCoverPhotoUrl());
        movie.setTrailerUrl(movieDTO.getTrailerUrl());
        return movie;
    }


}
