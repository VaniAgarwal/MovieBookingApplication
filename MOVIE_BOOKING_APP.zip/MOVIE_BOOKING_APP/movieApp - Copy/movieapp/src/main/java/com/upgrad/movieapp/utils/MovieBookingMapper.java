package com.upgrad.movieapp.utils;

import com.upgrad.movieapp.dto.MovieBookingDTO;
import com.upgrad.movieapp.dto.MovieDTO;
import org.modelmapper.ModelMapper;

public class MovieBookingMapper extends ModelMapper {

    public MovieBookingDTO mapEntityToDto(MovieBookingPOJO movieBookingPOJO) {


        MovieBookingDTO movieBookingDTO = new MovieBookingDTO();

        // Map the corresponding properties of the MovieBookingDTO object to the POJO object.
        movieBookingDTO.setMovieDTO(movieBookingPOJO.getMovieDTO());
        movieBookingDTO.setTheatreDTO(movieBookingPOJO.getTheatreDTO());
        movieBookingDTO.setUserDTO(movieBookingPOJO.getUserDTO());

        return movieBookingDTO;
    }


    public MovieBookingPOJO mapDtoToEntity(MovieBookingDTO movieBookingDTO) {
        MovieBookingPOJO movieBookingPOJO = new MovieBookingPOJO();

        movieBookingPOJO.setMovieDTO(movieBookingDTO.getMovieDTO());
        movieBookingPOJO.setTheatreDTO(movieBookingDTO.getTheatreDTO());
        movieBookingPOJO.setUserDTO(movieBookingDTO.getUserDTO());

        return movieBookingPOJO;
    }
}
