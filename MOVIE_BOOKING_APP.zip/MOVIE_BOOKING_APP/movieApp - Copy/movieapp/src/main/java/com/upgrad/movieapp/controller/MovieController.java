package com.upgrad.movieapp.controller;


import com.upgrad.movieapp.dao.MovieDAO;
import com.upgrad.movieapp.dto.MovieBookingDTO;
import com.upgrad.movieapp.dto.MovieDTO;
import com.upgrad.movieapp.entities.Movie;
import com.upgrad.movieapp.entities.Theatre;
import com.upgrad.movieapp.entities.User;
import com.upgrad.movieapp.services.MovieService;

import com.upgrad.movieapp.utils.CustomModelMapper;
import com.upgrad.movieapp.utils.MovieBookingMapper;
import com.upgrad.movieapp.utils.MovieBookingPOJO;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.attribute.standard.Media;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/movie_app/v1")
public class MovieController {

    @Autowired
    private MovieService movieService;

    @Autowired
    ModelMapper modelMapper;

    @Autowired
    MovieBookingMapper movieBookingMapper;



    //create movie 127.0.0.1:8080/movie_app/v1/movies

    @PostMapping(value = "/movies",consumes = MediaType.APPLICATION_JSON_VALUE,produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity createMovie(@RequestBody MovieDTO movieDTO){

        //convert movieDto to movieentity

        Movie newMovie = modelMapper.map(movieDTO,Movie.class);
        Movie savedMovie = movieService.acceptMovieDetails(newMovie);

        //movieentity to moviedto

        MovieDTO savedMovieDto = modelMapper.map(savedMovie,MovieDTO.class);

        return new ResponseEntity(savedMovieDto, HttpStatus.CREATED);


    }

    @GetMapping(value = "/allMovies" , consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity getAllMovies(){

        List<Movie> movieList = movieService.getAllMovies();
        List<MovieDTO> movieDTOList = new ArrayList<>();

        for(Movie movie:movieList){
            movieDTOList.add(modelMapper.map(movie,MovieDTO.class));

        }
        return new ResponseEntity(movieDTOList,HttpStatus.OK);

    }

    @GetMapping(value = "/movie/{id}")
    public ResponseEntity getMovieBasedOnId(@PathVariable(name = "id") int id){

        Movie responseMovie = movieService.getMovieDetails(id);

        MovieDTO responseMovieDto = modelMapper.map(responseMovie,MovieDTO.class);

        return new ResponseEntity<>(responseMovieDto,HttpStatus.OK);

    }

    @PutMapping(value = "/movieUpdate/{id}",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity updateMovieDetails(@PathVariable(name = "id") int id , @RequestBody MovieDTO movieDTO){

        Movie newMovie = modelMapper.map(movieDTO,Movie.class);

        Movie updateMovie = movieService.updateMovieDetails(id,newMovie);


        MovieDTO updatedMovieDto = modelMapper.map(updateMovie,MovieDTO.class);
        return new ResponseEntity(updatedMovieDto,HttpStatus.ACCEPTED);
    }


    @PostMapping(value = "/bookings/movie",consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity bookMovieDetails(@RequestBody MovieBookingDTO movieBookingDTO) throws Exception {
//        CustomModelMapper customModelMapper = new CustomModelMapper();
        MovieBookingPOJO movieBookingPOJO = movieBookingMapper.mapDtoToEntity(movieBookingDTO);

//        Movie requestedMovie = modelMapper.map(movieBookingDTO.getMovieDTO(),Movie.class);
//        User fromUser = modelMapper.map(movieBookingDTO.getUserDTO(),User.class);
//
//        Theatre requestedTheatre = modelMapper.map(movieBookingDTO.getTheatreDTO(),Theatre.class);

        boolean isBookingValid = movieService.bookMovie(movieBookingPOJO);

        if(!isBookingValid){
            return new ResponseEntity<>("Not Booked!!",HttpStatus.OK);

        }
        return new ResponseEntity("Booked Successfully",HttpStatus.OK);


    }
}
