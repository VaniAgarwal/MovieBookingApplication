package com.upgrad.movieapp.utils;

import com.upgrad.movieapp.dto.UserDTO;
import com.upgrad.movieapp.entities.User;
import org.modelmapper.ModelMapper;

public class UserMapper extends ModelMapper {

    public UserDTO userEntityToDTO(User user){

        UserDTO userDTO = new UserDTO();
        userDTO.setUserId(user.getUserId());
        userDTO.setFirstName(user.getFirstName());
        userDTO.setLastName(user.getLastName());
        userDTO.setUsername(user.getUserName());
        userDTO.setPassword(userDTO.getPassword());
        userDTO.setDateOfBirth(userDTO.getDateOfBirth());
        userDTO.setPhoneNumbers(userDTO.getPhoneNumbers());

        return userDTO;

    }

    public User userDTOtoEntity(UserDTO userDTO){

        User user = new User();
        user.setUserId(userDTO.getUserId());
        user.setFirstName(userDTO.getFirstName());
        user.setLastName(userDTO.getLastName());
        user.setUserName(userDTO.getUsername());
        user.setPassword(userDTO.getPassword());
        user.setDateOfbirth(userDTO.getDateOfBirth());
        user.setPhoneNumbers(userDTO.getPhoneNumbers());

        return user;
    }
}
