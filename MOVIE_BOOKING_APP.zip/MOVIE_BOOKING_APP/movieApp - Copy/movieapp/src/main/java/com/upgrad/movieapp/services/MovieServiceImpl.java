package com.upgrad.movieapp.services;

import com.upgrad.movieapp.dao.MovieDAO;
import com.upgrad.movieapp.entities.Movie;
import com.upgrad.movieapp.entities.Theatre;
import com.upgrad.movieapp.entities.User;
import com.upgrad.movieapp.feign.TheatreServiceClient;
import com.upgrad.movieapp.utils.MovieBookingPOJO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Pageable;
import org.springframework.web.client.RestTemplate;

import javax.transaction.Transactional;
import java.util.*;

@Service
public class MovieServiceImpl implements MovieService{

    @Value("${userApp.url}")
    private String userAppUrl;

    @Value("${theatreApp.url}")
    private String theatreAppUrl;
    @Autowired
    private MovieDAO movieDAO;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private TheatreServiceClient theatreServiceClient;

    @Override
    public Movie acceptMovieDetails(Movie movie) {
        return movieDAO.save(movie);
    }

    @Override
    @Transactional
    public List<Movie> acceptMultipleMovieDetails(List<Movie> movies) {

        List<Movie> savedMovies = new ArrayList<>();

        for(Movie movie:movies){
            savedMovies.add(acceptMovieDetails(movie));
        }


        return savedMovies;
    }

    @Override
    public Movie getMovieDetails(int id) {
        return movieDAO.findById(id).get();
    }

    @Override
    public Movie updateMovieDetails(int id, Movie movie) {

        Movie savedMovie = getMovieDetails(id);
        savedMovie.setMovieName(movie.getMovieName());
        savedMovie.setMovieDesc(movie.getMovieDesc());
        savedMovie.setDuration(movie.getDuration());
        savedMovie.setTrailerUrl(movie.getTrailerUrl());
        savedMovie.setCoverPhotoUrl(movie.getCoverPhotoUrl());
        savedMovie.setReleaseDate(movie.getReleaseDate());
        return movieDAO.save(savedMovie);

    }

    @Override
    public boolean deleteMovie(int id) {
        Movie savedMovie = getMovieDetails(id);

        if(savedMovie == null){
            return false;
        }
        movieDAO.delete(savedMovie);
        return true;
    }

    @Override
    public List<Movie> getAllMovies() {

        List<Movie> movies = movieDAO.findAll();

        return movies;
    }

    @Override
    public Page<Movie> getPaginatedMovieDetails(Pageable pageRequest) {

        return movieDAO.findAll(pageRequest);
    }

    @Override
    public Boolean bookMovie(MovieBookingPOJO movieBookingPOJO) {

        //Check whether requested movie is valid or not
        //for handling null we are using optional

        Optional<Movie> requestedMovie = movieDAO.findById(movieBookingPOJO.getMovieDTO().getMovie_id());

        if(!requestedMovie.isPresent()){
            return  false;
        }

        //check whether the user is valid or not
        Map<String,String> userUriMap = new HashMap<>();
//        System.out.println("String.valueOf(movieBookingPOJO.getUserDTO().getUserId())" +String.valueOf(movieBookingPOJO.getUserDTO().getUserId()));
        userUriMap.put("id",String.valueOf(movieBookingPOJO.getUserDTO().getUserId()));
        User receivedUser = restTemplate.getForObject(userAppUrl,User.class,userUriMap);
        if(receivedUser == null){
            return false;
        }

        //check whether theatre and movie combination is available
        Map<String,String> theatreUriMap = new HashMap<>();
        theatreUriMap.put("theatreId",String.valueOf(movieBookingPOJO.getTheatreDTO().getTheatreId()));
        theatreUriMap.put("movieId",String.valueOf(movieBookingPOJO.getTheatreDTO().getMovieId()));
        Theatre recievedThetre = theatreServiceClient.getTheatre(movieBookingPOJO.getTheatreDTO().getTheatreId(),movieBookingPOJO.getMovieDTO().getMovie_id());

        if(recievedThetre == null){
            return false;
        }
        return true;
    }
}
