package com.upgrad.movieapp.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "User")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int userId;

    @Column(name = "first_name" , nullable = false)
    private String firstName;

    @Column(name = "last_name" , nullable = false)
    private String lastName;

    @Column(name = "user_name" ,nullable = false,length = 10, unique = true)
    private String userName;

    @Column(name="password", nullable = false,length = 15)
    private String password;

    @Column(name = "date_of_birth", nullable = false)
    private LocalDateTime dateOfbirth;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "user_contact_number", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "phoneNumbers",nullable = false)
    private Set<Integer> phoneNumbers;


}
