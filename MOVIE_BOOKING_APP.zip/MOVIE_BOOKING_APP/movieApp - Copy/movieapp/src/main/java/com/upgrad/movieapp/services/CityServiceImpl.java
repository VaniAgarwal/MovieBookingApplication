//package com.upgrad.movieapp.services;
//
//import com.upgrad.movieapp.dao.CityDAO;
//import com.upgrad.movieapp.entities.City;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//
//@Service
//public class CityServiceImpl implements CityService {
//
//    @Autowired
//    private CityDAO cityDAO;
//
//    @Override
//    public City acceptCityDetails(City city) {
//
//        return cityDAO.save(city);
//    }
//
//    @Override
//    public City updateCityDetails(City city) {
//        City savedCity = getCityDetails(city.getCityId());
//        savedCity.setCityName(city.getCityName());
//        savedCity.setTheatres(city.getTheatres());
//
//        return  cityDAO.save(savedCity);
//    }
//
//    @Override
//    public City getCityDetails(int id) {
//        City cityDetails = cityDAO.findById(id).get();
//        return cityDetails;
//    }
//
//    @Override
//    public City getCityDetailsByCityName(String cityName) {
//        City cityDetails = cityDAO.findByCityName(cityName);
//        return cityDetails;
//    }
//
//    @Override
//    public boolean deleteCity(int id) {
//
//        City cityToBedeleted = getCityDetails(id);
//
//        if(cityToBedeleted == null){
//            return false;
//        }
//        cityDAO.delete(cityToBedeleted);
//        return true;
//    }
//
//    @Override
//    public List<City> getAllCityDetails() {
//        List<City> cities = cityDAO.findAll();
//        return cities;
//    }
//}
