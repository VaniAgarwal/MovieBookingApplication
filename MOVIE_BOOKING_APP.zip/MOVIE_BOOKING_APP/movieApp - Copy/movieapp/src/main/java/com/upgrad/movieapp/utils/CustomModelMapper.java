package com.upgrad.movieapp.utils;

import org.modelmapper.ModelMapper;

public class CustomModelMapper extends ModelMapper {
    public <S, T> T mapIfNotNull(S source, Class<T> targetType) {
        if (source != null) {
            return super.map(source, targetType);
        }
        return null;
    }
}
