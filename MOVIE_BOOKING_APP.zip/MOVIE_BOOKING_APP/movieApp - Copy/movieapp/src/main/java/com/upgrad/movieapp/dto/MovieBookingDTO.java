package com.upgrad.movieapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MovieBookingDTO {

    private MovieDTO movieDTO;
    private TheatreDTO theatreDTO;
    private UserDTO userDTO;


}
