package com.upgrad.movieapp;

//import com.upgrad.movieapp.dao.CustomerRepository;
import com.upgrad.movieapp.entities.Movie;
import com.upgrad.movieapp.services.MovieService;
import com.upgrad.movieapp.utils.MovieBookingMapper;
import com.upgrad.movieapp.utils.MovieMapper;
import com.upgrad.movieapp.utils.TheatreMapper;
import com.upgrad.movieapp.utils.UserMapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;


@RestController
@SpringBootApplication
@EnableFeignClients
public class MovieappApplication {//implements CommandLineRunner {

	@Autowired
	//CustomerRepository customerRepository;

	public static void main(String[] args) {

		ApplicationContext context = SpringApplication.run(MovieappApplication.class, args);

//		/**
//		 * Testing the movie service
//		 */
//		MovieService movieService = context.getBean(MovieService.class);
//		System.out.println("Movie service bean is created " +movieService);
//
//		Movie movie1 = new Movie();
//		movie1.setMovieName("GullyBoy");
//		movie1.setMovieDesc("Singer Storu");
//		movie1.setReleaseDate(LocalDateTime.of(2024,12,21,3,20));
//		movie1.setDuration(180);
//		movie1.setTrailerUrl("Trailer URl");
//		movie1.setCoverPhotoUrl("cover Url");
//
//
//		Movie savedMovie = movieService.acceptMovieDetails(movie1);
//		System.out.println("SavedMovie" +savedMovie);
	}

	@Bean
	public ModelMapper modelMapper(){
		return new ModelMapper();
	}

	@Bean
	public RestTemplate getRestTemplate(){
		return new RestTemplate();
	}

	@Bean
	public MovieBookingMapper movieBookingMapper(){
		return new MovieBookingMapper();
	}

	@Bean
	public TheatreMapper theatreMapper() {
		return new TheatreMapper();
	}

	@Bean
	public UserMapper userMapper() {
		return new UserMapper();
	}

	@Bean
	public MovieMapper movieMapper() {
		return new MovieMapper();
	}




//
//
//		Movie searchedMovie = movieService.getMovieDetails(savedMovie.getMovie_id());
//		System.out.println("SearchMovie" +searchedMovie);
//
//		/** Testing the city service */
//		CityService cityService = context.getBean(CityService.class);
//		System.out.println("City service bean is created" +cityService);
//
//		City city1 = new City();
//		city1.setCityName("Hyderabad");
//
//		City savedCity = cityService.acceptCityDetails(city1);
//		System.out.println("savedCity" +savedCity);


		/**
		 * Testing the theatre Service
		 */

//		TheatreService theatreService = context.getBean(TheatreService.class);
//		System.out.println("Theatre Servie bean is create: " +theatreService);
//
//		Theatre theatre = new Theatre();
//		theatre.setTheatreName("Bansal PLazza");
//		theatre.setTicketPrice(150.0f);
//
//		Theatre savedTheatre = theatreService.acceptTheatreDetails(theatre);
//		System.out.println("saved theatre " +savedTheatre);

		/**
		 * Testing the CustomerService
		 */
//
//		CustomerDAO customerDAO = context.getBean(CustomerDAO.class);
//
//		Customer customer = new Customer();
//		customer.setFirstName("Vani");
//		customer.setLastName("Agarwal");
//		customer.setUserName("vani033");
//		customer.setPassword("Ayush123#");
//		customer.setDateOfbirth(LocalDateTime.of(1992,03,04,0,0));
//
//		System.out.println("Before Saving " +customer);
//
//		Customer savedCustomer = customerDAO.save(customer);
//		System.out.println("After Saving " +customer);

		/**
		 * Crud operations on Moveie
		 * */

//		MovieDAO movieDAO = context.getBean(MovieDAO.class);
//
//		System.out.println(movieDAO);
//
//		Movie movie = new Movie();
//		movie.setMovieName("Sooryavansham");
//		movie.setMovieDesc("Amitabh Bachcchan Moview");
//		movie.setReleaseDate(LocalDateTime.of(2023,11,11,3,20));
//		movie.setDuration(150);
//		movie.setCoverPhotoUrl("ABC");
//		movie.setTrailerUrl("sdhbas");
//
//		System.out.println("Before Saving : " +movie);
//
//		Movie savedMovie = movieDAO.save(movie);
//
//		System.out.println("After Saving: " +savedMovie);
//		Movie retrievedMovie = movieDAO.findById(4).orElse(null);
//
//		System.out.println("Searrching: " +retrievedMovie);
//
//		movie.setMovieName("Farz");
//		Movie updatedMovie = movieDAO.save(movie);
//		System.out.println("Updated: " +updatedMovie);
//
//		movieDAO.deleteById(7);
//
//		System.out.println("deleting" +movieDAO.findById(7).orElse(null));

		/**
		 * Crud operations on Theatre
		 */

//		TheatreDAO theatreDAO = context.getBean(TheatreDAO.class);

//		Theatre theatre1 = new Theatre();
//		theatre1.setTheatreName("IONOX");
//		theatre1.setTicketPrice(250.00f);
//
//		System.out.println("Before Saving: " +theatre1);
//		Theatre savedTheatre = theatreDAO.save(theatre1);
//		System.out.println("After Saving: " +savedTheatre);
//
//
//		Theatre theatre2 = new Theatre();
//		theatre2.setTheatreName("Sheela Taakiz");
//		theatre2.setTicketPrice(150.00f);
//
//		System.out.println("Before Saving: " +theatre1);
//		Theatre savedTheatre2 = theatreDAO.save(theatre2);
//		System.out.println("After Saving: " +savedTheatre2);
//
//
//
//		Theatre theatre3 = new Theatre();
//		theatre3.setTheatreName("Basant Taakiz");
//		theatre3.setTicketPrice(100.0f);
//
//		System.out.println("Before Saving: " +theatre1);
//		Theatre savedTheatre3 = theatreDAO.save(theatre3);
//		System.out.println("After Saving: " +savedTheatre3);

		/*Getting the first page of a theatre*/

//		Page<Theatre> page1 = theatreDAO.findAll(PageRequest.of(0,3));
//		List<Theatre> theatreList2 = page1.getContent();
//
//		System.out.println(theatreList2);
//
//		if(page1.hasNext()){
//			System.out.println("Next Page");
//		}

		/*
		* Custom Query Methods*/

//		Theatre retrievedTheatre = theatreDAO.findByTheatreName("IONOX");
//		System.out.println(retrievedTheatre);
//
//		List<Theatre> retrievedBYTicketPrice = theatreDAO.findByTicketPriceLessThan(250.00f);
//		System.out.println(retrievedBYTicketPrice);
//
//		List<Theatre> retrievedBYNameContaining = theatreDAO.findByTheatreNameContaining("Taakiz");
//		System.out.println(retrievedBYNameContaining);



/*
	@Override
	public void run(String... args) throws Exception {
		Customer customer1 = new Customer(1,"Neetu","Agarwal","Geetu","*****", LocalDateTime.of(1992,10,17,3,20));
		Customer customer2 = new Customer(2,"Ritu","Agarwal","Ritu#","******", LocalDateTime.of(1992,11,16,3,20));
		Customer customer3 = new Customer(3,"Geetu","Agarwal","nhhbhds","******", LocalDateTime.of(2020,1,27,3,20));

	// Saving in Mongodb
//		customerRepository.save(customer1);
//		customerRepository.save(customer2);
//		customerRepository.save(customer3);

		//Fetching the data

//		for(Customer customer:customerRepository.findAll()){
//			System.out.println(customer);
//		}

		//find a record based on the firstname

		Customer customerRecord = customerRepository.findByFirstName("Neetu");
		System.out.println(customerRecord);

	}

 */
}