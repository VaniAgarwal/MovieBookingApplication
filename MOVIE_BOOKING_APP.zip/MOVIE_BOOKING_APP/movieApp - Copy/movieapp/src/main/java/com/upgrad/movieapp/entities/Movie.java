package com.upgrad.movieapp.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.util.Set;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
@Table(name = "Movie")
public class Movie {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int movie_id;

    @Column(name = "movie_name", nullable = false,unique = true)
    private String movieName;

    @Column(name = "movie_desc",nullable = false)
    private String movieDesc;

    @Column(name = "release_date",nullable = false)
    private LocalDateTime releaseDate;

    @Column(name = "duration",nullable = false)
    private int duration;

    @Column(name = "cover_photo_url",nullable = false)
    private String coverPhotoUrl;

    @Column(name = "trailer_url",nullable = false)
    private String trailerUrl;
//    private Status statusId;

    @ManyToMany(fetch = FetchType.EAGER)
    private Set<Theatre> theatres;


}
