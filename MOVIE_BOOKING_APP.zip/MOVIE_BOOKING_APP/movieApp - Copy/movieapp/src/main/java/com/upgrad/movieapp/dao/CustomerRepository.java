package com.upgrad.movieapp.dao;

//public interface CustomerRepository extends MongoRepository<Customer,Integer> {
//
//    public Customer findByFirstName(String firstName);
//    public List<Customer> findByLastName(String lastName);
//
//}
