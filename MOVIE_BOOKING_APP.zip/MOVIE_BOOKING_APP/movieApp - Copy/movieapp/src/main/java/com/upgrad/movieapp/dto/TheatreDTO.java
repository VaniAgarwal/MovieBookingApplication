package com.upgrad.movieapp.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TheatreDTO {

    private int theatreId;
    private String theatreName;
    private float ticketPrice = 150.00f;
    private int movieId;

}
