package com.upgrad.movieapp.utils;

import com.upgrad.movieapp.dto.TheatreDTO;
import com.upgrad.movieapp.entities.Theatre;
import org.modelmapper.ModelMapper;

public class TheatreMapper extends ModelMapper {

    public TheatreDTO TheatreEntityToDTO(Theatre theatreEntity){

        TheatreDTO theatreDTO = new TheatreDTO();
        theatreDTO.setTheatreId(theatreEntity.getTheatreId());
        theatreDTO.setTheatreName(theatreEntity.getTheatreName());
        theatreDTO.setMovieId(theatreEntity.getMovieId());
        theatreDTO.setTicketPrice(theatreEntity.getTicketPrice());

        return theatreDTO;

    }

    public Theatre TheatreDTOToEntity(TheatreDTO theatreDTO){

        Theatre theatre = new Theatre();
        theatre.setTheatreId(theatreDTO.getTheatreId());
        theatre.setTheatreName(theatreDTO.getTheatreName());
        theatre.setMovieId(theatreDTO.getMovieId());
        theatre.setTicketPrice(theatreDTO.getTicketPrice());

        return theatre;
    }
}
