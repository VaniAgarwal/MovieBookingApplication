package com.upgrad.movieapp.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//import javax.persistence.*;
//import java.util.Set;
//
//@NoArgsConstructor
//@AllArgsConstructor
//@Data
//@Entity
//@Table(name = "city")
//public class City {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    @Column(name = "city_id")
//    private int cityId;
//    @Column(name = "city_name",nullable = false)
//    private String cityName;
//
//    @OneToMany(mappedBy = "cityId", cascade = CascadeType.ALL)
//    private Set<Theatre> theatres;
//}
