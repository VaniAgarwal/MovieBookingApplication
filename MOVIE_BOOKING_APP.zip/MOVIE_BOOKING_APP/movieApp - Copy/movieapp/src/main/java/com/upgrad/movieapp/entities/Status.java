//package com.upgrad.movieapp.entities;
//
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import javax.persistence.*;
//
//@NoArgsConstructor
//@AllArgsConstructor
//@Data
//
//@Entity
//@Table(name = "status")
//public class Status {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.AUTO)
//    @Column(name = "status_id")
//    private int status_id;
//
//    @Column(name = "status_name",nullable = false,unique = true)
//    private String StatusName;
//
//
//}
