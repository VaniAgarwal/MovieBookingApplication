INSERT into movie(movie_id,movie_name,movie_duration) VALUES
(1,'Inception',120),
(2,'Tenet',200);